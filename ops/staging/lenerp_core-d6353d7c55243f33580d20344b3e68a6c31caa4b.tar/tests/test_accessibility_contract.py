from __future__ import annotations

from pathlib import Path


ROOT = Path(__file__).parents[1]
HOOKS = (ROOT / "lenerp_core" / "hooks.py").read_text(encoding="utf-8")
SCRIPT = (ROOT / "lenerp_core" / "public" / "js" / "accessibility.js").read_text(
    encoding="utf-8"
)


def test_accessibility_asset_is_included_on_authenticated_and_public_shells():
    assert 'app_include_js = ["/assets/lenerp_core/js/accessibility.js"]' in HOOKS
    assert 'web_include_js = ["/assets/lenerp_core/js/accessibility.js"]' in HOOKS


def test_rendered_shell_contract_removes_zoom_restrictions_and_labels_logos():
    assert 'meta[name="viewport"]' in SCRIPT
    assert 'width=device-width, initial-scale=1' in SCRIPT
    assert "user-scalable=no" not in SCRIPT
    assert "minimum-scale" not in SCRIPT
    assert 'setAttribute("alt", name)' in SCRIPT
    assert 'setAttribute("alt", "")' in SCRIPT
    assert ".app-logo" in SCRIPT
    assert ".splash img" in SCRIPT

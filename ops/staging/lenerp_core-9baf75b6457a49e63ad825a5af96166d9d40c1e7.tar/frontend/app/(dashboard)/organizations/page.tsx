import { redirect } from "next/navigation";

export default function OrganizationsPage() {
  redirect("/app/organizations");
}

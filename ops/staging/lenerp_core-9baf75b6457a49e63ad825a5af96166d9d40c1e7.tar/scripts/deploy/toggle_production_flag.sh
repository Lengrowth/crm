#!/usr/bin/env bash
set -Eeuo pipefail

EXPECTED_CURRENT_RELEASE="${EXPECTED_CURRENT_RELEASE:?Set EXPECTED_CURRENT_RELEASE to the release already serving production}"
PHASE1_SHELL_STATE="${PHASE1_SHELL_STATE:?Set PHASE1_SHELL_STATE to on or off}"
AUTH_TOKEN_FILE="${AUTH_TOKEN_FILE:?Set AUTH_TOKEN_FILE to the temporary smoke token path}"
BASE_URL="${BASE_URL:?Set BASE_URL to the production application origin}"
BACKEND_URL="${BACKEND_URL:?Set BACKEND_URL to the production backend origin}"
APP_ROOT="${APP_ROOT:-/opt/saas-control}"
BACKEND_ENV_FILE="${BACKEND_ENV_FILE:-$APP_ROOT/shared/env/backend.env}"
CURRENT_LINK="${CURRENT_LINK:-$APP_ROOT/current}"
BACKEND_SERVICE="${BACKEND_SERVICE:-saas-backend}"
SYSTEMCTL_BIN="${SYSTEMCTL_BIN:-/usr/bin/systemctl}"
LOCK_FILE="${LOCK_FILE:-/tmp/saas-control-production-flag.lock}"

case "$PHASE1_SHELL_STATE" in on|off) ;; *) echo "Invalid Phase 1 shell state" >&2; exit 1 ;; esac
[[ -r "$BACKEND_ENV_FILE" ]] || { echo "Production backend environment is missing" >&2; exit 1; }
actual_release="$(readlink -f "$CURRENT_LINK")"
[[ "$actual_release" == "$APP_ROOT/releases/$EXPECTED_CURRENT_RELEASE" ]] || {
  echo "Production release pointer changed; refusing flag-only update" >&2
  exit 1
}

exec 9>"$LOCK_FILE"
flock -n 9 || { echo "Another production flag transition is running." >&2; exit 1; }

restart_backend_cleanly() {
  sudo "$SYSTEMCTL_BIN" stop "$BACKEND_SERVICE"
  for _ in {1..15}; do
    if ! curl -fsS -o /dev/null --max-time 2 "${PRODUCTION_BACKEND_LOCAL_URL:-http://127.0.0.1:8001}/health"; then
      break
    fi
    sleep 1
  done
  sudo "$SYSTEMCTL_BIN" start "$BACKEND_SERVICE"
}

backup_file="/tmp/saas-control-production-flag.$$.env"
sudo cp -p "$BACKEND_ENV_FILE" "$backup_file"
restore() {
  sudo cp -p "$backup_file" "$BACKEND_ENV_FILE" 2>/dev/null || true
  restart_backend_cleanly >/dev/null 2>&1 || true
  sudo rm -f -- "$backup_file"
}
cleanup() { sudo rm -f -- "$backup_file"; }
trap cleanup EXIT

sudo python3 - "$BACKEND_ENV_FILE" "$PHASE1_SHELL_STATE" <<'PY'
from pathlib import Path
import re
import sys

path = Path(sys.argv[1])
state = sys.argv[2]
lines = path.read_text(encoding="utf-8").splitlines()
output = []
updated = False
feature_flags_pattern = re.compile(r"^\s*(?:export\s+)?FEATURE_FLAGS=")
for line in lines:
    if feature_flags_pattern.match(line):
        if updated:
            continue
        entries = [entry for entry in line.split("=", 1)[1].split(",") if entry and not entry.startswith("platform_phase1_shell=")]
        entries.append(f"platform_phase1_shell={state}")
        line = "FEATURE_FLAGS=" + ",".join(entries)
        updated = True
    output.append(line)
if not updated:
    output.append(f"FEATURE_FLAGS=platform_phase1_shell={state}")
path.write_text("\n".join(output) + "\n", encoding="utf-8")
PY

configured_flags="$(sudo python3 - "$BACKEND_ENV_FILE" <<'PY'
from pathlib import Path
import re
import sys

path = Path(sys.argv[1])
pattern = re.compile(r"^\s*(?:export\s+)?FEATURE_FLAGS=(.*)$")
print(",".join(match.group(1) for line in path.read_text(encoding="utf-8").splitlines() if (match := pattern.match(line))))
PY
)"
echo "Configured production feature flags: $configured_flags"
sudo "$SYSTEMCTL_BIN" daemon-reload
restart_backend_cleanly
loaded_flags="$(sudo "$SYSTEMCTL_BIN" show "$BACKEND_SERVICE" --property=Environment --value | tr ' ' '\n' | sed -n 's/^FEATURE_FLAGS=//p' | paste -sd ',' -)"
echo "Loaded backend feature flags: $loaded_flags"
backend_pid="$(pgrep -f 'uvicorn app.main:app --host 127.0.0.1 --port 8001' | head -n 1 || true)"
if [[ -n "$backend_pid" ]]; then
  process_flags="$(sudo tr '\0' '\n' < "/proc/$backend_pid/environ" | sed -n 's/^[Ff][Ee][Aa][Tt][Uu][Rr][Ee]_[Ff][Ll][Aa][Gg][Ss]=//p' | paste -sd ',' -)"
  echo "Backend process feature flags: $process_flags"
  application_flags="$(sudo -u ubuntu env FEATURE_FLAGS="$process_flags" PYTHONPATH="$APP_ROOT/current/backend" "$APP_ROOT/shared/backend-venv/bin/python" -c 'from app.core.config import settings; print(settings.feature_flags); print(settings.feature_flag_map)')"
  echo "Application settings feature flags: $application_flags"
fi
ready=false
for _ in {1..30}; do
  if curl -fsS -o /dev/null --max-time 3 "${PRODUCTION_BACKEND_LOCAL_URL:-http://127.0.0.1:8001}/health"; then ready=true; break; fi
  sleep 2
done
if [[ "$ready" != true ]]; then restore; exit 1; fi

expected_phase_one_shell="false"
[[ "$PHASE1_SHELL_STATE" == "on" ]] && expected_phase_one_shell="true"
if ! AUTH_TOKEN_FILE="$AUTH_TOKEN_FILE" BASE_URL="$BASE_URL" BACKEND_URL="${PRODUCTION_BACKEND_LOCAL_URL:-http://127.0.0.1:8001}" EXPECTED_RELEASE="$EXPECTED_CURRENT_RELEASE" EXPECTED_PHASE_ONE_SHELL="$expected_phase_one_shell" bash "$APP_ROOT/current/scripts/release/shell_smoke.sh"; then
  restore
  exit 1
fi

[[ "$(readlink -f "$CURRENT_LINK")" == "$APP_ROOT/releases/$EXPECTED_CURRENT_RELEASE" ]] || { restore; exit 1; }
echo "Production flag-only transition completed for $EXPECTED_CURRENT_RELEASE: $PHASE1_SHELL_STATE"

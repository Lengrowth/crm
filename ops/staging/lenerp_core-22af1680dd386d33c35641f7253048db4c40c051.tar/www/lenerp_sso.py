"""Browser entry route for the isolated LenERP central sign-in bridge."""

import frappe

from lenerp_core.sso import _redirect_to, _start_transaction


no_cache = 1


def get_context(context: dict[str, object]) -> dict[str, object]:
    _redirect_to(_start_transaction(frappe.form_dict.get("next_path", "/app")))
    return context

from frappe.www.app import get_context as _get_context


def get_context(context):
	return _get_context(context)
